"""
EmailPilot FastAPI Application with Google Cloud Firestore Integration

This version uses Google Cloud Firestore for all data storage.
Cloud-native database for better scalability and reliability.
"""
from fastapi import FastAPI, Request, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse, HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from starlette.middleware.gzip import GZipMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware
import os
import json
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict, Any
import logging
import sys
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Set up logging
logging.basicConfig(level=logging.INFO)
try:
    # Attach a rotating file handler for app logs (safe in local/dev)
    from app.utils.logging_utils import setup_rotating_file_logging
    setup_rotating_file_logging("emailpilot_app", logfile=os.path.join("logs", "emailpilot_app.log"))
except Exception:
    # Best-effort; continue if helper unavailable
    pass
logger = logging.getLogger(__name__)

# Initialize LangSmith Tracing
try:
    from app.core.langsmith_config import setup_langsmith_tracing
    tracing_status = setup_langsmith_tracing("emailpilot-calendar")
    if tracing_status["enabled"]:
        logger.info(f"🔍 LangSmith tracing active for project: {tracing_status['project']}")
except Exception as e:
    logger.warning(f"LangSmith tracing setup skipped: {e}")

# IMPORTANT: Ensure we're running the correct implementation
# This prevents accidentally running old calendar-project code
CORRECT_IMPLEMENTATION_MARKER = "main_firestore.py"
current_file = os.path.basename(__file__)
if current_file != CORRECT_IMPLEMENTATION_MARKER:
    logger.warning(f"⚠️  Warning: Running from {current_file} instead of {CORRECT_IMPLEMENTATION_MARKER}")
    logger.warning("⚠️  Make sure you're using the correct EmailPilot implementation!")

# Ensure we're not importing from old calendar-project
if 'calendar-project' in sys.path or 'calendar_project' in str(Path.cwd()):
    logger.error("❌ ERROR: Old calendar-project detected in path!")
    logger.error("❌ Please run from /emailpilot-app/ directory instead")
    logger.error("❌ Use: uvicorn main_firestore:app --reload --port 8000")
    sys.exit(1)

# Import API routers
from app.api.admin import router as admin_router
from app.api.admin_users import router as admin_users_router

from app.api.calendar import router as calendar_router
from app.api.calendar_enhanced import router as calendar_enhanced_router
from app.api.calendar_planning import router as calendar_planning_router
from app.api.calendar_planning_ai import router as calendar_planning_ai_router
from app.api.calendar_planning_templates import router as calendar_planning_templates_router
# from app.api.calendar_orchestrator_v2 import router as calendar_orchestrator_v2_router  # Enhanced multi-agent version
from app.api.firebase_calendar import router as firebase_calendar_router

# Import LangSmith-traced calendar router
try:
    from app.api.calendar_langsmith import router as calendar_langsmith_router
    CALENDAR_LANGSMITH_AVAILABLE = True
    logger.info("✅ Calendar LangSmith integration loaded successfully")
except ImportError as e:
    calendar_langsmith_router = None
    CALENDAR_LANGSMITH_AVAILABLE = False
    logger.warning(f"Calendar LangSmith integration not available: {e}")
    
from app.api.mcp_local import router as mcp_router
from app.api.mcp_chat import router as mcp_chat_router

# Import MCP Klaviyo router 
from app.api.mcp_klaviyo import router as mcp_klaviyo_router

# Import MCP Gateway router (NEW - Routes to Enhanced or Fallback MCP)
try:
    from app.api.mcp_gateway import router as mcp_gateway_router
    MCP_GATEWAY_AVAILABLE = True
    logger.info("✅ MCP Gateway router loaded - Enhanced MCP integration ready")
except ImportError as e:
    mcp_gateway_router = None
    MCP_GATEWAY_AVAILABLE = False
    logger.warning(f"MCP Gateway router not available: {e}")

# Import MCP Natural Language router (NEW - Natural language interface for MCP)
try:
    from app.api.mcp_natural_language import router as mcp_natural_language_router
    MCP_NL_AVAILABLE = True
    logger.info("✅ MCP Natural Language router loaded - Chat interface ready")
except ImportError as e:
    mcp_natural_language_router = None
    MCP_NL_AVAILABLE = False
    logger.warning(f"MCP Natural Language router not available: {e}")

# Import Klaviyo Discovery router
from app.api.klaviyo_discovery import router as klaviyo_discovery_router

# Import admin client management router
from app.api.admin_clients import router as admin_clients_router

# Import admin firestore router
from app.api.admin_firestore import router as admin_firestore_router

# Import admin secret manager router
from app.api.admin_secret_manager import router as admin_secret_manager_router
from app.api.admin_services import router as admin_services_router

# Import admin notifications router
from app.api.admin_notifications import router as admin_notifications_router

# Import proxy router for CORS-safe image loading
try:
    from app.api.proxy import router as proxy_router
    PROXY_AVAILABLE = True
except ImportError:
    proxy_router = None
    PROXY_AVAILABLE = False
    logger.info("Proxy router not available")

# Import LangChain admin router
try:
    import sys
    sys.path.insert(0, "multi-agent")
    from integrations.langchain_core.admin.api import router as langchain_admin_router
    LANGCHAIN_ADMIN_AVAILABLE = True
    logger.info("LangChain admin API available")
except ImportError as e:
    langchain_admin_router = None
    LANGCHAIN_ADMIN_AVAILABLE = False
    logger.info(f"LangChain admin API not available: {e}")

# Import auth router
from app.api.auth import router as auth_router

# Try to import auth_v2, fall back to lite version if Clerk SDK not available
try:
    from app.api.auth_v2 import router as auth_v2_router
    logger.info("✅ Auth V2 with Clerk SDK loaded")
except ImportError as e:
    logger.warning(f"Clerk SDK not available, using lite version: {e}")
    from app.api.auth_v2_lite import router as auth_v2_router
    logger.info("✅ Auth V2 Lite (no SDK) loaded")

# Import service OAuth router (for Asana/Klaviyo integration)
try:
    from app.api.service_oauth import router as service_oauth_router
    logger.info("Service OAuth module available (Asana/Klaviyo)")
except ImportError:
    service_oauth_router = None
    logger.info("Service OAuth module not available")

# Import Klaviyo OAuth router (for new OAuth integration)
try:
    from app.api.integrations.klaviyo_oauth import router as klaviyo_oauth_router
    logger.info("✅ Klaviyo OAuth integration module loaded successfully")
except ImportError as e:
    klaviyo_oauth_router = None
    logger.error(f"❌ Klaviyo OAuth integration module not available: {e}")

# Import Google auth router (legacy)
try:
    from app.api.auth_google import router as google_auth_router
except ImportError:
    google_auth_router = None

# Import goals router - Now using Firestore
from app.api.goals import router as goals_router
from app.api.goals2 import router as goals2_router

# Import performance router - Now simplified  
from app.api.performance import router as performance_router

# Import reports router - Now simplified
from app.api.reports import router as reports_router
from app.api.reports_mcp import router as reports_mcp_router
from app.api.reports_mcp_v2 import router as reports_mcp_v2_router
from app.api.asana import router as asana_router
from app.api.admin_asana import router as admin_asana_router
from app.api.asana_oauth import router as asana_oauth_router

# Import dashboard router - Now uses Firestore
from app.api.dashboard import router as dashboard_router

# Import agents router (legacy)
from app.api.agents import router as agents_router

# Import unified agents router (NEW - Single Source of Truth)
try:
    from app.api.agents_unified import router as agents_unified_router
    AGENTS_UNIFIED_AVAILABLE = True
except ImportError:
    agents_unified_router = None
    AGENTS_UNIFIED_AVAILABLE = False
    logger.info("Unified agents router not available")

# Import AI Orchestrator - DISABLED IN FAVOR OF LANGCHAIN
# from app.api.ai_orchestrator import router as ai_orchestrator_router
ai_orchestrator_router = None

# Import LangChain Admin API (alternative implementation with dependency issues)
# NOTE: Disabled due to missing get_config() function and other dependencies
# Try alternative LangChain Admin API if multi-agent version failed
if not LANGCHAIN_ADMIN_AVAILABLE:
    try:
        from app.api.langchain_admin_full import router as langchain_admin_router_alt
        langchain_admin_router = langchain_admin_router_alt
        LANGCHAIN_ADMIN_AVAILABLE = True
        logger.info("✅ Alternative LangChain Admin API loaded successfully")
    except ImportError as e:
        logger.warning(f"Alternative LangChain Admin API not available: {e}")

# Import AI models management router (LEGACY - use orchestrator instead)
try:
    from app.api.ai_models import router as ai_models_router
    AI_MODELS_AVAILABLE = True
except ImportError:
    ai_models_router = None
    AI_MODELS_AVAILABLE = False
    logger.info("AI models management router not available")

# Import agent configuration router
try:
    from app.api.agent_config import router as agent_config_router
    AGENT_CONFIG_AVAILABLE = True
except ImportError:
    agent_config_router = None
    AGENT_CONFIG_AVAILABLE = False

# Import agent creator router
try:
    from app.api.agent_creator import router as agent_creator_router
    AGENT_CREATOR_AVAILABLE = True
    logger.info("✅ Agent Creator API loaded successfully")
except ImportError as e:
    agent_creator_router = None
    AGENT_CREATOR_AVAILABLE = False
    logger.warning(f"Agent Creator API not available: {e}")

# Import tools router for external Klaviyo tools integration
try:
    from app.api.tools import router as tools_router
    TOOLS_AVAILABLE = True
except ImportError:
    tools_router = None
    TOOLS_AVAILABLE = False
    logger.info("Tools router not available")

# Email/SMS MCP agents removed - using LangChain multi-agent system instead
AGENT_ROUTERS_AVAILABLE = False
logger.info("Agent routers not available (optional feature)")

# Check if admin agents router is available
try:
    import app.api.admin_agents as admin_agents
    ADMIN_AGENT_ROUTERS_AVAILABLE = True
except ImportError:
    ADMIN_AGENT_ROUTERS_AVAILABLE = False
    logger.info("Admin agent routers not available (optional feature)")

import signal
import requests

# Import the new SecretManagerService
from app.services.secrets import SecretManagerService, SecretError, SecretNotFoundError, SecretPermissionError

# Import settings for configuration
from app.core.settings import get_settings

# Google Cloud Firestore
try:
    from google.cloud import firestore
    from app.deps.firestore import get_db
except ImportError:
    raise ImportError("google-cloud-firestore not installed. Run: pip install google-cloud-firestore")



# Approved email addresses - Add your team members here
APPROVED_EMAILS = [
    "damon@dspkmarketing.com",
    "user@emailpilot.ai",
    "admin@emailpilot.ai"
]

app = FastAPI(
    title="EmailPilot API",
    description="Klaviyo automation platform with integrated calendar and performance monitoring",
    version="2.0.0"
)

# Templates (MPA) setup
templates = Jinja2Templates(directory="templates")
try:
    from app.utils.assets import vite_assets
    # Make helper available in templates
    templates.env.globals["vite_assets"] = vite_assets
except Exception as e:
    logger.warning(f"Vite manifest helper unavailable: {e}")

from app.deps import get_secret_manager_service
from app.middleware.security import RequestIDMiddleware, LoggingMiddleware, SecurityHeadersMiddleware
from app.middleware.ratelimit import RateLimitMiddleware
from app.utils.logging_utils import setup_json_console_logging

@app.on_event("startup")
async def startup_probe():
    """Validate critical configuration at startup."""
    project_id = os.getenv("GOOGLE_CLOUD_PROJECT")
    logger.info(f"🚀 Starting up with Google Cloud Project ID: {project_id}")
    try:
        # Check if GOOGLE_CLOUD_PROJECT is set
        if not project_id:
            raise RuntimeError("GOOGLE_CLOUD_PROJECT environment variable not set.")

        # Test Secret Manager connection
        secret_manager = get_secret_manager_service()
        # Try to get a non-existent secret to check permissions
        try:
            secret_manager.get_secret("this-secret-should-not-exist")
        except SecretNotFoundError:
            logger.info("✅ Secret Manager health check passed (test secret not found as expected).")
        except SecretPermissionError:
            logger.error("❌ STARTUP PROBE FAILED: Insufficient permissions for Secret Manager.")
            raise
        except SecretError as e:
            logger.error(f"❌ STARTUP PROBE FAILED: Secret Manager error: {e}")
            raise

        # Test Firestore connection
        from app.services.firestore import ping

        try:
            ping(get_db())
            logger.info("✅ Firestore health check passed")
        except Exception as e:
            logger.warning(f"⚠️  Firestore health check had issues but continuing: {e}")

    except Exception as e:
        logger.error(f"❌ STARTUP PROBE FAILED: {e}")
        # Re-raise to prevent app from starting with missing configuration
        raise

# Optional JSON logging for Cloud Run
if os.getenv("LOG_FORMAT", "text").lower() == "json":
    setup_json_console_logging(level=logging.INFO)

# Add session middleware for OAuth
session_secret = get_settings().secret_key
app.add_middleware(SessionMiddleware, secret_key=session_secret)

# Compression for responses
app.add_middleware(GZipMiddleware, minimum_size=1024)

# Request ID + request logging
app.add_middleware(RequestIDMiddleware)
app.add_middleware(LoggingMiddleware)

# Trusted hosts (optional)
trusted_hosts = [h.strip() for h in os.getenv("TRUSTED_HOSTS", "").split(",") if h.strip()]
if trusted_hosts:
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=trusted_hosts)

# Security headers (disable in local dev)
security_enabled = os.getenv("ENVIRONMENT", "development").lower() != "development"
app.add_middleware(SecurityHeadersMiddleware, enabled=security_enabled)

# Rate limiting: default 120 req/min per IP/path; stricter on auth endpoints
rl_default_max = int(os.getenv("RL_DEFAULT_MAX", "120"))
rl_default_window = int(os.getenv("RL_DEFAULT_WINDOW", "60"))
rl_auth_max = int(os.getenv("RL_AUTH_MAX", "20"))
rl_auth_window = int(os.getenv("RL_AUTH_WINDOW", "60"))
path_limits = {
    "/api/auth/login": (rl_auth_max, rl_auth_window),
    "/api/auth/google/login": (rl_auth_max, rl_auth_window),
}
app.add_middleware(RateLimitMiddleware, default_max=rl_default_max, default_window=rl_default_window, path_limits=path_limits)

# Configure CORS with comprehensive origins and headers
allow_all = os.getenv("CORS_ALLOW_ALL", "false").lower() == "true"
cors_origins_env = [o.strip() for o in os.getenv("CORS_ORIGINS", "").split(",") if o.strip()]
default_origins = [
        "http://localhost:8000",
        "http://127.0.0.1:8000",
        "http://localhost:3000", 
        "http://127.0.0.1:3000",
        "http://localhost:3001",
        "http://127.0.0.1:3001",
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "https://emailpilot.ai",
        "https://www.emailpilot.ai",
]
cors_origins = cors_origins_env or default_origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if allow_all else cors_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"],
    allow_headers=[
        "Authorization",
        "Content-Type", 
        "Accept",
        "Origin",
        "X-Requested-With",
        "X-CSRF-Token",
        "X-API-Key",
        "Cache-Control"
    ],
    expose_headers=[
        "X-Total-Count",
        "X-Page-Count", 
        "Link"
    ]
)

# Basic health endpoint for Cloud Run and load balancers
@app.get("/health")
async def health_root():
    return {"status": "ok"}

# Firestore helper functions
def doc_to_dict(doc) -> Dict[str, Any]:
    """Convert Firestore document to dictionary with ID"""
    if not doc.exists:
        return None
    data = doc.to_dict()
    data['id'] = doc.id
    return data

def collection_to_list(docs) -> List[Dict[str, Any]]:
    """Convert Firestore documents to list of dictionaries"""
    return [doc_to_dict(doc) for doc in docs if doc.exists]


# Health check endpoints
@app.get("/api/")
async def root():
    return {
        "status": "healthy",
        "service": "EmailPilot API",
        "version": "2.0.0", 
        "database": "Firestore"
    }

# Simple health endpoint for monitoring
@app.get("/health")
async def health():
    """Lightweight health check endpoint for monitoring systems."""
    return {"status": "ok"}

# Version endpoint for deployment tracking
@app.get("/version")
async def version():
    """Version information endpoint for deployment tracking."""
    return {"version": "1.0.0"}

# Legacy clients endpoint (for backwards compatibility)
@app.get("/api/clients/")
async def get_clients_legacy():
    """Legacy endpoint for clients list - redirects to admin endpoint"""
    try:
        db = get_db()
        docs = list(db.collection("clients").stream())
        clients = []
        
        for doc in docs:
            if doc.exists:
                data = doc.to_dict()
                clients.append({
                    "id": doc.id,
                    "name": data.get("name", "Unknown"),
                    "metric_id": data.get("metric_id", ""),
                    "is_active": data.get("is_active", True),
                    "contact_email": data.get("contact_email", ""),
                    "website": data.get("website", "")
                })
        
        return clients
    except Exception as e:
        logger.error(f"Error fetching clients: {e}")
        return []

# Stub endpoints for admin dashboard compatibility
@app.get("/api/admin")
async def admin_dashboard_root():
    """Admin dashboard root endpoint"""
    return {
        "status": "operational",
        "service": "EmailPilot Admin API",
        "version": "2.0.0",
        "message": "Admin API is operational"
    }

@app.get("/api/calendar")
async def calendar_dashboard_root():
    """Calendar dashboard root endpoint"""
    return {
        "status": "operational", 
        "service": "EmailPilot Calendar API",
        "version": "2.0.0",
        "message": "Calendar API is operational"
    }

@app.get("/api/goals")
async def goals_dashboard_root():
    """Goals dashboard root endpoint"""
    return {
        "status": "operational",
        "service": "EmailPilot Goals API", 
        "version": "2.0.0",
        "message": "Goals API is operational"
    }

@app.get("/api/mcp")
async def mcp_dashboard_root():
    """MCP dashboard root endpoint"""
    return {
        "status": "operational",
        "service": "EmailPilot MCP API",
        "version": "2.0.0", 
        "message": "MCP API is operational"
    }

@app.get("/api/agents")
async def agents_dashboard_root():
    """Agents dashboard root endpoint"""
    return {
        "status": "operational",
        "service": "EmailPilot Agents API",
        "version": "2.0.0",
        "message": "Agents API is operational"
    }

@app.post("/api/dev/telemetry")
async def dev_telemetry(request: Request):
    """Debug telemetry endpoint for client-side error reporting"""
    try:
        data = await request.json()
        # Log with clear prefix for CLI tailing
        logger.info(f"DEV_TELEMETRY: {json.dumps(data)}")
        return {"status": "received"}
    except Exception as e:
        logger.error(f"DEV_TELEMETRY_ERROR: {str(e)}")
        return {"status": "error", "message": str(e)}


# Static file routes - Legacy support for direct paths
@app.get("/app.js")
async def get_app():
    """Legacy route - redirect to static mount"""
    return FileResponse('frontend/public/dist/app.js', media_type='application/javascript')

@app.get("/logo.png")
async def get_logo():
    return FileResponse('frontend/public/logo.png', media_type='image/png')

@app.get("/logo2.png")
async def get_logo2():
    return FileResponse('frontend/public/logo2.png', media_type='image/png')

@app.get("/components/{filename}")
async def get_component(filename: str):
    """Legacy route - redirect to static mount"""
    return FileResponse(f'frontend/public/dist/{filename}', media_type='application/javascript')

@app.get("/dist/{filename}")
async def get_dist_component(filename: str):
    """Serve compiled components from dist directory"""
    return FileResponse(f'frontend/public/dist/{filename}', media_type='application/javascript')

# (Legacy SPA index removed; MPA route defined later.)



@app.get("/test_oauth_frontend.html")
async def get_oauth_test():
    return FileResponse('frontend/public/test_oauth_frontend.html')

@app.get("/test-goals-working.html")
async def get_goals_test():
    return FileResponse('test-goals-working.html')

@app.get("/test-goals-dashboard.html")
async def get_goals_dashboard_test():
    return FileResponse('test-goals-dashboard.html')

@app.get("/test-goals-final.html")
async def get_goals_final_test():
    return FileResponse('test-goals-final.html')

@app.get("/test_navigation.html")
async def get_navigation_test():
    return FileResponse('test_navigation.html')

@app.get("/user-management")
async def get_user_management_page():
    return FileResponse('frontend/public/user-management.html')

@app.get("/admin-dashboard")
async def get_admin_dashboard():
    return FileResponse('frontend/public/admin-dashboard.html')

@app.get("/calendar-legacy")
async def get_calendar_legacy():
    """Serve production calendar page"""
    return FileResponse('frontend/public/calendar.html')

@app.get("/calendar.html")
async def get_calendar_html():
    """Redirect to isolated static calendar under /static/standalone-calendar"""
    return RedirectResponse(url="/static/standalone-calendar/index.html")

@app.get("/calendar-debug")
async def get_calendar_debug():
    """Serve calendar debug harness - exact production clone with optional debug overlay"""
    return FileResponse('frontend/public/calendar_debug.html')

@app.get("/health-detailed")
async def health_check():
    try:
        # Test Firestore connection
        db = get_db()
        test_doc = db.collection('_health').document('test')
        test_doc.set({'timestamp': datetime.utcnow().isoformat()})
        test_doc.delete()
        
        return {
            "status": "healthy",
            "database": "Firestore connected",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Health check failed: {str(e)}")

# Include API routers with proper prefixes
app.include_router(admin_router, prefix="/api/admin", tags=["Administration"])
app.include_router(admin_users_router, tags=["Admin Users"])

# Include calendar routers with appropriate prefixes
app.include_router(calendar_router, prefix="/api/calendar", tags=["Calendar"])
app.include_router(calendar_enhanced_router, prefix="/api/calendar", tags=["Calendar Enhanced"])
app.include_router(calendar_planning_router, tags=["AI Calendar Planning"])
app.include_router(calendar_planning_ai_router, tags=["Calendar Planning AI with MCP"])
app.include_router(calendar_planning_templates_router, tags=["Calendar Planning Templates"])
app.include_router(firebase_calendar_router, prefix="/api/firebase-calendar", tags=["Firebase Calendar"])

# Include LangSmith-traced calendar router if available
if CALENDAR_LANGSMITH_AVAILABLE:
    app.include_router(calendar_langsmith_router, tags=["Calendar LangSmith"])
    logger.info("✅ Calendar LangSmith routes registered")

# Calendar Orchestrator - LangChain-powered automation
try:
    from app.api.calendar_orchestrator import router as calendar_orchestrator_router
    app.include_router(calendar_orchestrator_router, prefix="/api/calendar", tags=["Calendar Orchestrator"])
    logger.info("✅ Calendar Orchestrator router loaded successfully")
except Exception as e:
    logger.error(f"❌ Failed to load Calendar Orchestrator router: {e}")

# Enhanced Calendar Orchestrator V2 - Multi-Agent with Klaviyo Enhanced MCP
# app.include_router(calendar_orchestrator_v2_router, tags=["Calendar Orchestrator V2"])
logger.info("✅ Calendar Orchestrator V2 (Multi-Agent) router included with Klaviyo Enhanced MCP integration")

# MCP Management routers
app.include_router(mcp_router, prefix="/api/mcp", tags=["MCP Management"])
app.include_router(mcp_chat_router, tags=["MCP Chat"])

# Direct Klaviyo API integration for MCP Chat
try:
    from app.api.mcp_chat_direct import router as mcp_chat_direct_router
    app.include_router(mcp_chat_direct_router, tags=["MCP Direct"])
    logger.info("✅ MCP Direct Klaviyo API integration enabled")
except Exception as e:
    logger.warning(f"MCP Direct integration not available: {e}")

# LangChain Natural Language Interface for Klaviyo
try:
    from app.api.langchain_klaviyo import router as langchain_klaviyo_router
    app.include_router(langchain_klaviyo_router, tags=["LangChain Klaviyo"])
    logger.info("✅ LangChain Natural Language interface for Klaviyo enabled")
except Exception as e:
    logger.warning(f"LangChain Klaviyo integration not available: {e}")

# LangChain Debug Interface
try:
    from app.api.langchain_debug import router as langchain_debug_router
    app.include_router(langchain_debug_router, tags=["LangChain Debug"])
    logger.info("✅ LangChain Debug interface enabled")
except Exception as e:
    logger.warning(f"LangChain Debug interface not available: {e}")

# Include LangChain Execute interface for synchronous agent execution
try:
    from app.api.langchain_execute import router as langchain_execute_router
    app.include_router(langchain_execute_router, tags=["LangChain Execute"])
    logger.info("✅ LangChain Execute interface enabled - Synchronous agent execution")
except Exception as e:
    logger.warning(f"LangChain Execute interface not available: {e}")

# Klaviyo Feedback and Validation System
try:
    from app.api.klaviyo_feedback import router as klaviyo_feedback_router
    app.include_router(klaviyo_feedback_router, tags=["Klaviyo Feedback"])
    logger.info("✅ Klaviyo Feedback and Validation system enabled")
except Exception as e:
    logger.warning(f"Klaviyo Feedback system not available: {e}")

# MCP Klaviyo Management
app.include_router(mcp_klaviyo_router, prefix="/api/mcp/klaviyo", tags=["MCP Klaviyo Management"])

# Include MCP Gateway router if available (Enhanced MCP integration)
if MCP_GATEWAY_AVAILABLE:
    app.include_router(mcp_gateway_router, tags=["MCP Gateway"])
    logger.info("✅ MCP Gateway router registered - Enhanced MCP ready")

# Include MCP Natural Language router if available (Natural language interface)
if MCP_NL_AVAILABLE:
    app.include_router(mcp_natural_language_router, tags=["MCP Natural Language"])
    logger.info("✅ MCP Natural Language router registered - Chat interface ready")

# Klaviyo Account Discovery
app.include_router(klaviyo_discovery_router, prefix="/api/klaviyo", tags=["Klaviyo Account Discovery"])

# Admin client management router - already has /api/admin/clients prefix internally
app.include_router(admin_clients_router, tags=["Admin Client Management"])

# Admin Firestore router
app.include_router(admin_firestore_router, prefix="/api/admin/firestore", tags=["Admin Firestore Configuration"])

# Admin Secret Manager router
app.include_router(admin_secret_manager_router, tags=["Admin Secret Manager"])

# Admin Services Catalog router
app.include_router(admin_services_router, tags=["Admin Services"])

# Admin Notifications router
app.include_router(admin_notifications_router, tags=["Admin Notifications"])

# Proxy router for CORS-safe image loading
if PROXY_AVAILABLE and proxy_router:
    app.include_router(proxy_router, tags=["Proxy"])
    logger.info("✅ Image proxy router enabled for CORS-safe avatar loading")

# Authentication routers
# Always use Google auth router which has both JWT and session support
if google_auth_router:
    app.include_router(google_auth_router, prefix="/api/auth/google", tags=["Google Authentication"])
    logger.info("✅ Authentication enabled with Google OAuth, Email/Password, and Guest access")
    
    # Compatibility shim to expose /api/auth/me and /api/auth/login
    try:
        from app.api.auth_compat import router as auth_compat_router
        app.include_router(auth_compat_router, prefix="/api/auth", tags=["Authentication Compatibility"])
        logger.info("🔗 Auth compatibility shim enabled under /api/auth")
    except Exception as e:
        logger.warning(f"Auth compatibility shim unavailable: {e}")
else:
    app.include_router(auth_router, prefix="/api/auth", tags=["Authentication"])
    logger.info("🔒 Using basic authentication")
    
    # Legacy Google Authentication router - only if available
    if google_auth_router:
        app.include_router(google_auth_router, prefix="/api/auth/google", tags=["Google Authentication"])

# Always include modern auth v2 router (works with or without Google auth)
app.include_router(auth_v2_router, prefix="/api/auth/v2", tags=["Authentication V2"])
logger.info("✅ Auth V2 router included with Clerk support")
logger.info("✅ Auth V2 router included with Clerk/multi-tenant support")

# Service OAuth router for Asana/Klaviyo integrations (separate from user auth)
if service_oauth_router:
    app.include_router(service_oauth_router, prefix="/api/integrations", tags=["Service Integrations"])
    logger.info("✅ Service integrations enabled (Asana/Klaviyo OAuth)")

# Klaviyo OAuth router for new OAuth integration with auto-client creation
if klaviyo_oauth_router:
    app.include_router(klaviyo_oauth_router, prefix="/api/integrations/klaviyo", tags=["Klaviyo OAuth"])
    logger.info("✅ Klaviyo OAuth integration enabled with auto-client creation at /api/integrations/klaviyo")

# Goals router - Now using Firestore
app.include_router(goals_router, prefix="/api/goals", tags=["Goals Management"])
app.include_router(goals2_router, prefix="/api/goals2", tags=["Goals Management 2"])

# Performance router - Now simplified
app.include_router(performance_router, tags=["Performance Metrics"])

# Reports router - Now simplified
app.include_router(reports_router, tags=["Reports"])
app.include_router(reports_mcp_router, tags=["MCP Reports"])
app.include_router(reports_mcp_v2_router, tags=["MCP Reports V2"])

# Dashboard router - Now uses Firestore
app.include_router(dashboard_router, prefix="/api/dashboard", tags=["Dashboard"])

# Agents router (legacy)
app.include_router(agents_router, prefix="/api/agents", tags=["Agents (Legacy)"])
# Unified Agents router - SINGLE SOURCE OF TRUTH (use this!)
if AGENTS_UNIFIED_AVAILABLE and agents_unified_router:
    app.include_router(agents_unified_router, tags=["Unified Agents - SSOT"])
    logger.info("✅ Unified Agents router enabled - Single Source of Truth for all agents")

# AI Orchestrator router - PRIMARY AI INTERFACE (use this!)
# app.include_router(ai_orchestrator_router, tags=["AI Orchestrator"])  # DISABLED - Using LangChain

# Include LangChain Admin API
if LANGCHAIN_ADMIN_AVAILABLE:
    app.include_router(langchain_admin_router, tags=["LangChain Admin"])
logger.info("✅ LangChain enabled - Primary AI interface")

# Include LangChain Orchestration API
try:
    from app.api.langchain_orchestration import router as orchestration_router
    app.include_router(orchestration_router, tags=["LangChain Orchestration"])
    logger.info("✅ LangChain Orchestration API enabled - Variable discovery & MCP coordination")
except ImportError as e:
    logger.warning(f"LangChain Orchestration API not available: {e}")

# AI Models Management router - LEGACY (disabled in favor of LangChain)
# if AI_MODELS_AVAILABLE and ai_models_router:
#     app.include_router(ai_models_router, tags=["AI Models Management (Legacy)"])
#     logger.info("⚠️  AI Models Management router enabled (LEGACY - use Orchestrator instead)")

# Agent Configuration router - manages agent-to-prompt mappings
if AGENT_CONFIG_AVAILABLE and agent_config_router:
    app.include_router(agent_config_router, tags=["Agent Configuration"])
    logger.info("✅ Agent Configuration router enabled")

# Agent Creator router - create and optimize new agents
if AGENT_CREATOR_AVAILABLE and agent_creator_router:
    app.include_router(agent_creator_router, tags=["Agent Creator"])
    logger.info("✅ Agent Creator router enabled - Create and optimize new AI agents")

# Tools router - integrates external Klaviyo audit and management tools
if TOOLS_AVAILABLE and tools_router:
    app.include_router(tools_router, prefix="/api/tools", tags=["External Tools"])
    logger.info("✅ External Tools router enabled")

# Asana integration router
app.include_router(asana_router)
app.include_router(admin_asana_router)
app.include_router(asana_oauth_router)

# Workflow API for LangGraph visual editor (using fixed version)
try:
    from app.api.workflow_fixed import router as workflow_router
    app.include_router(workflow_router, tags=["Workflow"])
    logger.info("✅ Workflow API enabled for LangGraph editor (fixed)")
except ImportError as e:
    # Fallback to original if fixed not available
    try:
        from app.api.workflow import router as workflow_router
        app.include_router(workflow_router, tags=["Workflow"])
        logger.info("✅ Workflow API enabled for LangGraph editor")
    except ImportError:
        logger.info(f"ℹ️ Workflow API not available: {e}")

# Variables API for agent development (independent of workflow) - Updated
try:
    from app.api.variables import router as variables_router
    app.include_router(variables_router, tags=["Variables"])
    logger.info("✅ Variables API enabled for agent development")
except ImportError as e:
    logger.warning(f"Variables API not available: {e}")

# Hub Dashboard API for LangGraph integration
try:
    from app.api.hub import router as hub_router
    app.include_router(hub_router, tags=["Hub Dashboard"])
    logger.info("✅ Hub Dashboard API enabled for LangGraph integration")
except ImportError as e:
    logger.warning(f"Hub Dashboard API not available: {e}")

# Email/SMS MCP agent routers removed - replaced by LangChain system

# Conditionally include admin agent routers  
if ADMIN_AGENT_ROUTERS_AVAILABLE:
    # Only include admin agent routes if the module is available
    try:
        app.include_router(admin_agents.router, prefix="/api/agents/admin", tags=["Admin Agent Management"])
    except Exception as e:
        logger.warning(f"Could not include admin agent router: {e}")

# Admin endpoints are now handled by the admin router included above

# File serving for static assets
from pathlib import Path as _Path
_BASE_DIR = _Path(__file__).resolve().parent

# Mount static files from frontend/public directory at /static
# This serves files like /static/dist/app.js, /static/components/, etc.
app.mount("/static", StaticFiles(directory="frontend/public"), name="static")

# Serve the Vite-built frontend as the primary static directory
# This mount serves the compiled SPA files directly at root
app.mount("/", StaticFiles(directory="dist", html=True), name="spa")
# Explicit route for test HTML files
@app.get("/test-endpoints.html")
async def serve_test_endpoints():
    """Serve the test endpoints HTML page"""
    return FileResponse('frontend/public/test-endpoints.html')

@app.get("/hub/")
async def serve_hub_dashboard():
    """Serve the Hub Dashboard for LangGraph integration"""
    return FileResponse('frontend/public/hub/index.html')

@app.get("/test_hidden_endpoints.html")
async def serve_test_hidden_endpoints():
    """Serve the test hidden endpoints HTML page"""
    import os
    if os.path.exists('test_hidden_endpoints.html'):
        return FileResponse('test_hidden_endpoints.html')
    elif os.path.exists('frontend/public/test_hidden_endpoints.html'):
        return FileResponse('frontend/public/test_hidden_endpoints.html')
    else:
        raise HTTPException(status_code=404, detail="Test file not found")

# ============ MPA Routes (Server-rendered) ============
@app.get("/")
async def root_spa(request: Request):
    """Serves the main index.html file for the React SPA."""
    return FileResponse('dist/index.html')


@app.get("/clients")
async def mpa_clients(request: Request):
    return templates.TemplateResponse("clients.html", {"request": request, "active": "clients", "entry_name": "clients"})


@app.get("/calendar")
async def mpa_calendar(request: Request):
    return templates.TemplateResponse("calendar.html", {"request": request, "active": "calendar", "entry_name": "calendar"})


@app.get("/reports")
async def mpa_reports(request: Request):
    return templates.TemplateResponse("reports.html", {"request": request, "active": "reports", "entry_name": "reports"})


@app.get("/settings")
async def mpa_settings(request: Request):
    return templates.TemplateResponse("settings.html", {"request": request, "active": "settings", "entry_name": "settings"})


@app.get("/admin")
async def mpa_admin(request: Request):
    return templates.TemplateResponse("admin/index.html", {"request": request, "active": "admin", "entry_name": "admin"})

@app.get("/admin/{path:path}")
async def mpa_admin_catchall(request: Request, path: str):
    return templates.TemplateResponse("admin/index.html", {"request": request, "active": "admin", "entry_name": "admin", "subpath": path})


# ============ Developer Telemetry ============
@app.post("/api/dev/telemetry")
async def dev_telemetry(payload: dict, request: Request):
    try:
        client_ip = request.client.host if request.client else "?"
        logger.info(f"DEV_TELEMETRY: ip={client_ip} {payload}")
        return {"ok": True}
    except Exception as e:
        logger.error(f"DEV_TELEMETRY_ERROR: {e}")
        return JSONResponse(status_code=500, content={"ok": False})

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Global exception: {exc}")
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error"}
    )

# (Legacy SPA handlers removed; MPA routes are defined above.)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main_firestore:app", host="0.0.0.0", port=8000, reload=True)
# Log asset 404s for /static/dist to aid debugging and CI visibility
@app.middleware("http")
async def asset_404_telemetry(request: Request, call_next):
    response = await call_next(request)
    try:
        path = request.url.path
        if response.status_code == 404 and (path.startswith('/static/dist/') or path.startswith('/static/') or path.startswith('/frontend/dist/')):
            logger.info(f"DEV_TELEMETRY: asset_404 path={path} status=404")
    except Exception:
        pass
    return response
