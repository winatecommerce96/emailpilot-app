// EmailPilot Firebase Configuration
window.FIREBASE_CONFIG = {
    apiKey: "AIzaSyB0RrH7hbER2R-SzXfNmFe0O32HhH7HBEM",
    authDomain: "emailpilot-438321.firebaseapp.com",
    projectId: "emailpilot-438321",
    storageBucket: "emailpilot-438321.appspot.com",
    messagingSenderId: "104067375141",
    appId: "1:104067375141:web:2b65c86eec8e8c8b4c9f3a"
};

window.GEMINI_API_KEY = "AIzaSyDZxn9-FekvRhcvRfneulDrebD0RFxUpvs";
window.GOOGLE_API_KEY = "AIzaSyAMeP8IjAfqmHAh7MeN5lpu2OpHhfRTTEg";
window.GOOGLE_CLIENT_ID = "1058910766003-pqu4avth8ltclpbtpk81k0ln21dl8jue.apps.googleusercontent.com";
