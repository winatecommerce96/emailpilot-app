#!/bin/bash
# LangChain runner script
python lc.py "$@"
