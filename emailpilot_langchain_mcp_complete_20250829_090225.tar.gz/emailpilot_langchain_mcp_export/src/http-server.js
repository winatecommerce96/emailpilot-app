#!/usr/bin/env node
/**
 * HTTP Server Wrapper for Klaviyo MCP Enhanced
 * Provides HTTP endpoints that bridge to MCP protocol
 */

import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = process.env.PORT || 9095;

app.use(cors());
app.use(express.json());

// Store MCP process
let mcpProcess = null;
let mcpReady = false;

/**
 * Start MCP server as subprocess
 */
function startMCPServer() {
    console.log('Starting MCP server subprocess...');
    
    mcpProcess = spawn('node', [join(__dirname, 'index.js')], {
        stdio: ['pipe', 'pipe', 'pipe'],
        env: { ...process.env }
    });
    
    mcpProcess.stdout.on('data', (data) => {
        const output = data.toString();
        console.log('MCP:', output);
        if (output.includes('ready') || output.includes('connected')) {
            mcpReady = true;
        }
    });
    
    mcpProcess.stderr.on('data', (data) => {
        console.error('MCP Error:', data.toString());
    });
    
    mcpProcess.on('close', (code) => {
        console.log(`MCP process exited with code ${code}`);
        mcpReady = false;
    });
    
    // Give it a moment to start
    setTimeout(() => {
        mcpReady = true;
        console.log('MCP server marked as ready');
    }, 2000);
}

/**
 * Send request to MCP and get response
 */
async function callMCP(method, params) {
    return new Promise((resolve, reject) => {
        if (!mcpProcess || !mcpReady) {
            reject(new Error('MCP server not ready'));
            return;
        }
        
        const request = {
            jsonrpc: '2.0',
            id: Date.now(),
            method: method,
            params: params
        };
        
        // For this HTTP wrapper, we'll use the tool functions directly
        // since the MCP server is stdio-based
        // Import and call the tools directly
        
        import('./tools/campaigns.js').then(module => {
            if (method === 'campaigns.list') {
                module.getCampaigns(params).then(resolve).catch(reject);
            } else {
                reject(new Error(`Unknown method: ${method}`));
            }
        }).catch(reject);
    });
}

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({
        status: mcpReady ? 'operational' : 'starting',
        service: 'Klaviyo MCP Enhanced HTTP Wrapper',
        ready: mcpReady,
        timestamp: new Date().toISOString()
    });
});

// MCP invoke endpoint
app.post('/mcp/invoke', async (req, res) => {
    try {
        const { method, params } = req.body;
        
        // Extract API key from params or headers
        const apiKey = params?.apiKey || req.headers['x-klaviyo-api-key'];
        
        if (!apiKey) {
            return res.status(401).json({
                error: 'API key required',
                details: 'Pass apiKey in params or X-Klaviyo-API-Key header'
            });
        }
        
        // Dynamic import based on tool category
        const [category, action] = method.split('.');
        let result;
        
        switch(category) {
            case 'campaigns': {
                const { getCampaigns, getCampaign } = await import('./tools/campaigns.js');
                if (action === 'list') {
                    result = await getCampaigns({ ...params, apiKey });
                } else if (action === 'get') {
                    result = await getCampaign(params.id, apiKey);
                }
                break;
            }
            case 'metrics': {
                const { getMetrics, getMetric, queryMetricAggregates } = await import('./tools/metrics.js');
                if (action === 'list') {
                    result = await getMetrics({ ...params, apiKey });
                } else if (action === 'get') {
                    result = await getMetric(params.id, apiKey);
                } else if (action === 'aggregate') {
                    result = await queryMetricAggregates({ ...params, apiKey });
                }
                break;
            }
            case 'segments': {
                const { getSegments, getSegment } = await import('./tools/segments.js');
                if (action === 'list') {
                    result = await getSegments({ ...params, apiKey });
                } else if (action === 'get') {
                    result = await getSegment(params.id, apiKey);
                }
                break;
            }
            case 'profiles': {
                const { getProfile, createProfile, updateProfile } = await import('./tools/profiles.js');
                if (action === 'get') {
                    result = await getProfile(params.id, apiKey);
                } else if (action === 'create') {
                    result = await createProfile(params.data, apiKey);
                } else if (action === 'update') {
                    result = await updateProfile(params.id, params.data, apiKey);
                }
                break;
            }
            case 'lists': {
                const { getLists, getList } = await import('./tools/lists.js');
                if (action === 'list') {
                    result = await getLists({ ...params, apiKey });
                } else if (action === 'get') {
                    result = await getList(params.id, apiKey);
                }
                break;
            }
            case 'flows': {
                const { getFlows, getFlow } = await import('./tools/flows.js');
                if (action === 'list') {
                    result = await getFlows({ ...params, apiKey });
                } else if (action === 'get') {
                    result = await getFlow(params.id, apiKey);
                }
                break;
            }
            case 'templates': {
                const { getTemplates, getTemplate } = await import('./tools/templates.js');
                if (action === 'list') {
                    result = await getTemplates({ ...params, apiKey });
                } else if (action === 'get') {
                    result = await getTemplate(params.id, apiKey);
                }
                break;
            }
            case 'events': {
                const { createEvent, getEvents } = await import('./tools/events.js');
                if (action === 'create') {
                    result = await createEvent(params.data, apiKey);
                } else if (action === 'list') {
                    result = await getEvents({ ...params, apiKey });
                }
                break;
            }
            case 'reporting': {
                const { getCampaignPerformance } = await import('./tools/reporting.js');
                if (action === 'revenue' || action === 'performance') {
                    result = await getCampaignPerformance(params.campaignId, params.metricIds, apiKey);
                }
                break;
            }
            default:
                return res.status(400).json({
                    error: 'Unknown tool category',
                    details: `Tool category '${category}' not found`
                });
        }
        
        res.json({
            success: true,
            data: result,
            method: method,
            timestamp: new Date().toISOString()
        });
        
    } catch (error) {
        console.error('MCP invoke error:', error);
        res.status(500).json({
            error: 'MCP invocation failed',
            details: error.message
        });
    }
});

// List available tools
app.get('/mcp/tools', (req, res) => {
    res.json({
        tools: [
            // Campaigns
            { method: 'campaigns.list', description: 'List campaigns' },
            { method: 'campaigns.get', description: 'Get campaign by ID' },
            // Metrics
            { method: 'metrics.list', description: 'List metrics' },
            { method: 'metrics.get', description: 'Get metric by ID' },
            { method: 'metrics.aggregate', description: 'Query metric aggregates' },
            // Segments
            { method: 'segments.list', description: 'List segments' },
            { method: 'segments.get', description: 'Get segment by ID' },
            // Profiles
            { method: 'profiles.get', description: 'Get profile by ID' },
            { method: 'profiles.create', description: 'Create new profile' },
            { method: 'profiles.update', description: 'Update profile' },
            // Lists
            { method: 'lists.list', description: 'List all lists' },
            { method: 'lists.get', description: 'Get list by ID' },
            // Flows
            { method: 'flows.list', description: 'List flows' },
            { method: 'flows.get', description: 'Get flow by ID' },
            // Templates
            { method: 'templates.list', description: 'List templates' },
            { method: 'templates.get', description: 'Get template by ID' },
            // Events
            { method: 'events.create', description: 'Create event' },
            { method: 'events.list', description: 'List events' },
            // Reporting
            { method: 'reporting.revenue', description: 'Get revenue reports' },
            { method: 'reporting.performance', description: 'Get performance reports' }
        ],
        total: 20,
        categories: 9
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Klaviyo MCP Enhanced HTTP Server running on port ${PORT}`);
    console.log(`   Health: http://localhost:${PORT}/health`);
    console.log(`   Tools: http://localhost:${PORT}/mcp/tools`);
    console.log(`   Invoke: POST http://localhost:${PORT}/mcp/invoke`);
    
    // Start MCP subprocess
    startMCPServer();
});