#!/usr/bin/env node
/**
 * Simple HTTP Wrapper for Klaviyo MCP Enhanced
 * Direct Klaviyo API calls with HTTP interface
 */

import express from 'express';
import cors from 'cors';
import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 9095;
const KLAVIYO_API_BASE = 'https://a.klaviyo.com/api';

app.use(cors());
app.use(express.json());

// Make direct Klaviyo API call
async function callKlaviyoAPI(endpoint, method = 'GET', data = null, apiKey) {
    const url = `${KLAVIYO_API_BASE}${endpoint}`;
    
    const config = {
        method: method,
        url: url,
        headers: {
            'Authorization': `Klaviyo-API-Key ${apiKey}`,
            'revision': '2024-06-15',
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
    };
    
    if (data && method !== 'GET') {
        config.data = data;
    }
    
    if (method === 'GET' && data) {
        config.params = data;
    }
    
    try {
        const response = await axios(config);
        return response.data;
    } catch (error) {
        console.error('Klaviyo API error:', error.response?.data || error.message);
        throw error;
    }
}

// Health check
app.get('/health', (req, res) => {
    res.json({
        status: 'operational',
        service: 'Klaviyo MCP Enhanced HTTP',
        timestamp: new Date().toISOString()
    });
});

// MCP invoke endpoint - maps tool calls to Klaviyo API
app.post('/mcp/invoke', async (req, res) => {
    try {
        const { method, params } = req.body;
        const apiKey = params?.apiKey || req.headers['x-klaviyo-api-key'];
        
        if (!apiKey) {
            return res.status(401).json({
                error: 'API key required'
            });
        }
        
        let result;
        const [category, action] = method.split('.');
        
        // Map tool methods to Klaviyo API endpoints
        switch(method) {
            case 'campaigns.list':
                // Fix parameter names - Klaviyo campaigns endpoint doesn't support page[size]
                const campaignParams = {};
                
                if (params.filter) campaignParams.filter = params.filter;
                else campaignParams.filter = "equals(messages.channel,'email')";
                
                result = await callKlaviyoAPI('/campaigns', 'GET', campaignParams, apiKey);
                break;
                
            case 'campaigns.get':
                result = await callKlaviyoAPI(`/campaigns/${params.id}`, 'GET', null, apiKey);
                break;
                
            case 'metrics.list':
                // Metrics endpoint doesn't support page[size] either
                const metricsParams = {};
                if (params.filter) metricsParams.filter = params.filter;
                
                result = await callKlaviyoAPI('/metrics', 'GET', metricsParams, apiKey);
                break;
                
            case 'metrics.get':
                result = await callKlaviyoAPI(`/metrics/${params.id}`, 'GET', null, apiKey);
                break;
                
            case 'metrics.aggregate':
                result = await callKlaviyoAPI('/metric-aggregates', 'POST', {
                    data: {
                        type: 'metric-aggregate',
                        attributes: {
                            metric_id: params.metric_id,
                            measurements: params.measurements || ['sum_value', 'count'],
                            interval: params.interval || 'day',
                            filter: params.filter || [],
                            timezone: params.timezone || 'UTC'
                        }
                    }
                }, apiKey);
                break;
                
            case 'segments.list':
                result = await callKlaviyoAPI('/segments', 'GET', {}, apiKey);
                break;
                
            case 'segments.get':
                result = await callKlaviyoAPI(`/segments/${params.id}`, 'GET', null, apiKey);
                break;
                
            case 'profiles.get':
                result = await callKlaviyoAPI(`/profiles/${params.id}`, 'GET', null, apiKey);
                break;
                
            case 'lists.list':
                result = await callKlaviyoAPI('/lists', 'GET', {}, apiKey);
                break;
                
            case 'lists.get':
                result = await callKlaviyoAPI(`/lists/${params.id}`, 'GET', null, apiKey);
                break;
                
            case 'flows.list':
                result = await callKlaviyoAPI('/flows', 'GET', {}, apiKey);
                break;
                
            case 'flows.get':
                result = await callKlaviyoAPI(`/flows/${params.id}`, 'GET', null, apiKey);
                break;
                
            case 'templates.list':
                result = await callKlaviyoAPI('/templates', 'GET', {}, apiKey);
                break;
                
            case 'templates.get':
                result = await callKlaviyoAPI(`/templates/${params.id}`, 'GET', null, apiKey);
                break;
                
            case 'events.create':
                result = await callKlaviyoAPI('/events', 'POST', params.data, apiKey);
                break;
                
            case 'reporting.revenue':
            case 'reporting.performance':
                // Custom implementation for performance reporting
                const campaignId = params.campaignId;
                const metrics = await callKlaviyoAPI(`/campaigns/${campaignId}/metrics`, 'GET', null, apiKey);
                result = metrics;
                break;
                
            default:
                return res.status(400).json({
                    error: `Unknown method: ${method}`
                });
        }
        
        res.json({
            success: true,
            data: result,
            method: method,
            timestamp: new Date().toISOString()
        });
        
    } catch (error) {
        console.error('MCP invoke error:', error.message);
        
        // Check if it's an Axios error with response
        if (error.response) {
            res.status(error.response.status).json({
                error: 'Klaviyo API error',
                details: error.response.data,
                status: error.response.status
            });
        } else {
            res.status(500).json({
                error: 'MCP invocation failed',
                details: error.message
            });
        }
    }
});

// List available tools
app.get('/mcp/tools', (req, res) => {
    res.json({
        tools: [
            { method: 'campaigns.list', description: 'List campaigns' },
            { method: 'campaigns.get', description: 'Get campaign by ID' },
            { method: 'metrics.list', description: 'List metrics' },
            { method: 'metrics.get', description: 'Get metric by ID' },
            { method: 'metrics.aggregate', description: 'Aggregate metrics' },
            { method: 'segments.list', description: 'List segments' },
            { method: 'segments.get', description: 'Get segment by ID' },
            { method: 'profiles.get', description: 'Get profile by ID' },
            { method: 'lists.list', description: 'List all lists' },
            { method: 'lists.get', description: 'Get list by ID' },
            { method: 'flows.list', description: 'List flows' },
            { method: 'flows.get', description: 'Get flow by ID' },
            { method: 'templates.list', description: 'List templates' },
            { method: 'templates.get', description: 'Get template by ID' },
            { method: 'events.create', description: 'Create event' },
            { method: 'reporting.revenue', description: 'Revenue reporting' },
            { method: 'reporting.performance', description: 'Performance reporting' }
        ],
        total: 17
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Klaviyo MCP Enhanced HTTP Server`);
    console.log(`   Port: ${PORT}`);
    console.log(`   Health: http://localhost:${PORT}/health`);
    console.log(`   Tools: http://localhost:${PORT}/mcp/tools`);
    console.log(`   Ready for requests!`);
});