#!/bin/bash
# EmailPilot Package System - Installation Script
# This file is for EmailPilot's package system compatibility

# Run the main deployment script
bash deploy.sh