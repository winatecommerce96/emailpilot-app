# Cloud Run Services Integration Guide for MCP

## 🎯 Services to Check

Based on your EmailPilot deployment, you should check these Cloud Run services:

### 1. Primary API Service
**Service Name:** `emailpilot-api` or `emailpilot-app`
- **Region:** us-central1
- **URL:** https://emailpilot.ai (custom domain) or https://emailpilot-api-[hash]-uc.a.run.app
- **Purpose:** Main FastAPI backend that needs MCP routes added

### 2. Check Which Services Exist
Run this command to list all your Cloud Run services:

```bash
gcloud run services list --region=us-central1 --project=emailpilot-438321
```

Look for services with names like:
- `emailpilot-api`
- `emailpilot-app` 
- `emailpilot-backend`
- `emailpilot-firestore`
- `emailpilot`

## 📋 Steps to Integrate MCP in Cloud Run

### Step 1: Access Google Cloud Console
1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Select project: `emailpilot-438321`
3. Navigate to **Cloud Run** in the left menu

### Step 2: Find the Right Service
Look for the service that:
- Has the most recent deployments
- Shows traffic being served
- Has the custom domain mapping to emailpilot.ai
- Has environment variables like `DATABASE_URL`, `KLAVIYO_API_KEY`

### Step 3: Check Service Details
Click on the service and check:
- **Logs tab** - Look for startup logs mentioning FastAPI routes
- **Revisions tab** - See deployment history
- **Metrics tab** - Verify it's receiving traffic
- **YAML tab** - Check the container configuration

### Step 4: Access the Container

#### Option A: Cloud Shell Editor
```bash
# Open Cloud Shell
gcloud cloud-shell ssh

# Clone the latest revision
gcloud run services describe emailpilot-api \
  --region=us-central1 \
  --format=export > service.yaml

# Check the container image
grep "image:" service.yaml
```

#### Option B: Direct Container Access
```bash
# Get the latest revision name
gcloud run revisions list \
  --service=emailpilot-api \
  --region=us-central1 \
  --limit=1 \
  --format="value(name)"

# Download the container locally (if needed)
gcloud run services describe emailpilot-api \
  --region=us-central1 \
  --format="value(spec.template.spec.containers[0].image)"
```

### Step 5: Check Current Routes
Look in the service logs for route registration:

```bash
# View recent logs
gcloud run logs read \
  --service=emailpilot-api \
  --region=us-central1 \
  --limit=50 \
  | grep -E "(include_router|/api/)"
```

You should see lines like:
```
app.include_router(auth_router, prefix="/api/auth")
app.include_router(clients_router, prefix="/api/clients")
# BUT NOT YET: app.include_router(mcp_router, prefix="/api/mcp")
```

## 🔧 How to Add MCP Routes

### Method 1: Update via Cloud Build (Recommended)
If you have a cloudbuild.yaml:

1. **Update main_firestore.py locally** with:
```python
from app.api.mcp import router as mcp_router
app.include_router(mcp_router, prefix="/api/mcp", tags=["mcp"])
```

2. **Deploy new revision:**
```bash
gcloud builds submit --config cloudbuild.yaml
```

### Method 2: Direct Revision Update
1. **Create new revision with updated code:**
```bash
# First, get current configuration
gcloud run services describe emailpilot-api \
  --region=us-central1 \
  --format=export > service.yaml

# Edit the service.yaml to include new environment variable
# Add under spec.template.spec.containers[0].env:
- name: MCP_ENABLED
  value: "true"

# Deploy the update
gcloud run services replace service.yaml --region=us-central1
```

### Method 3: Use Cloud Console UI
1. Go to Cloud Run → emailpilot-api
2. Click **"Edit & Deploy New Revision"**
3. Go to **"Container, Variables & Secrets, Connections, Security"**
4. Under **Variables & Secrets**, add:
   - `MCP_ENABLED` = `true`
5. Click **"Deploy"**

## 🔍 Verify MCP Integration

After updating, check if MCP routes are working:

```bash
# Get the service URL
SERVICE_URL=$(gcloud run services describe emailpilot-api \
  --region=us-central1 \
  --format="value(status.url)")

# Test MCP endpoints (you'll need a valid token)
curl -X GET "$SERVICE_URL/api/mcp/models" \
  -H "Authorization: Bearer YOUR_TOKEN"

# Or test via custom domain
curl -X GET "https://emailpilot.ai/api/mcp/models" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## 📊 Service Architecture

Your EmailPilot deployment likely looks like this:

```
┌─────────────────────────────────┐
│   Cloud Run Service              │
│   emailpilot-api                 │
│                                  │
│   Container:                     │
│   - FastAPI application          │
│   - main_firestore.py           │ ← MCP routes need to be added here
│   - /app/api/                   │
│   - /app/services/              │
│   - /app/models/                │
└─────────────────────────────────┘
           │
           ▼
┌─────────────────────────────────┐
│   Firestore Database             │
│   - clients collection           │
│   - mcp_clients collection      │ ← New collection for MCP
│   - reports collection           │
└─────────────────────────────────┘
```

## 🚨 Common Issues

### Issue: Can't find the right service
**Solution:** Look for the service that:
- Has endpoint `/api/clients` working (your existing clients)
- Returns data when you visit https://emailpilot.ai/health
- Shows FastAPI in the logs

### Issue: Changes don't appear after deployment
**Solution:** 
- Make sure traffic is routed to the latest revision
- Check Cloud Run → Service → Revisions → Manage Traffic
- Ensure 100% traffic goes to the latest revision

### Issue: Container doesn't have MCP files
**Solution:**
The files might be in the staging directory. You need to:
1. Include them in your Docker image
2. Or mount them as a volume
3. Or copy them during the build process

## 📝 Quick Commands Reference

```bash
# List services
gcloud run services list --region=us-central1

# Describe service
gcloud run services describe emailpilot-api --region=us-central1

# View logs
gcloud run logs read --service=emailpilot-api --region=us-central1 --limit=100

# Deploy new revision
gcloud run deploy emailpilot-api --source . --region=us-central1

# Update traffic split
gcloud run services update-traffic emailpilot-api \
  --region=us-central1 \
  --to-latest

# Check service URL
gcloud run services describe emailpilot-api \
  --region=us-central1 \
  --format="value(status.url)"
```

## ✅ Success Indicators

You'll know MCP is integrated when:
1. `/api/mcp/models` returns 200 instead of 404
2. Logs show "Including router mcp_router"
3. The MCP Management UI loads data properly
4. Testing buttons work without errors

## 🆘 If You Need Help

1. Check the service logs for errors:
   ```bash
   gcloud run logs read --service=emailpilot-api --region=us-central1 | grep -i error
   ```

2. Verify the service is running:
   ```bash
   curl https://emailpilot.ai/health
   ```

3. Check if the staged files exist in the container:
   - Look for `/app/staged_packages/mcp*`
   - Or `/tmp/mcp*`

The key is finding the `emailpilot-api` service (or whatever your main API service is named) and adding the MCP router registration to its main_firestore.py file.